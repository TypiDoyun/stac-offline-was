export const toRadians = (degrees: number) => {
    return (degrees * Math.PI) / 180; // 전달된 60분법 각도를 호도법으로 변환하는 기능을 한다.
};
